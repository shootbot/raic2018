public class Solid {
    Vec3d pos;
    Vec3d speed;
    
    public Solid() {
    }
    
    public Solid(Vec3d pos, Vec3d speed) {
        this.pos = pos;
        this.speed = speed;
    }
}
