
public class MyNitroPack extends Entity {
    public int id;

    public double nitro_amount;
    public int respawn_ticks;
    public boolean alive;
}
