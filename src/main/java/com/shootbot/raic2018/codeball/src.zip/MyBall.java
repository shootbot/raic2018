public class MyBall extends Entity {
    
    public MyBall(Vec3d ball) {
        this.x = ball.x;
        this.y = ball.y;
        this.z = ball.z;
    }
}
